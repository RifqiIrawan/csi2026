          <footer class="footer">
            <div class="d-sm-flex justify-content-center">
              <span class="text-muted d-block text-center text-sm-left d-sm-inline-block text-center"><b>Copyright © <?php echo date("Y")?> PT. Kelie Chemical World. All Right Reserved</b></span>
              <!-- <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"> <b>Versi 1.0</b></span> -->
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?php echo base_url();?>assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    
    <script src="<?php echo base_url();?>assets/vendors/select2/select2.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/progressbar.js/progressbar.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/jvectormap/jquery-jvectormap.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/owl-carousel-2/owl.carousel.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo base_url();?>assets/js/off-canvas.js"></script>
    <script src="<?php echo base_url();?>assets/js/hoverable-collapse.js"></script>
    <script src="<?php echo base_url();?>assets/js/misc.js"></script>
    <script src="<?php echo base_url();?>assets/js/settings.js"></script>
    <script src="<?php echo base_url();?>assets/js/todolist.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="<?php echo base_url();?>assets/js/dashboard.js"></script>    
    <script src="<?php echo base_url();?>assets/js/select2.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>