<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require'header.php';
require'menu.php';
echo $contents;
require'footer.php';