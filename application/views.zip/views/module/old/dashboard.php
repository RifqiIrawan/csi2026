<?php 
  if($this->session->flashdata('simpan')){
    echo '<script type="text/javascript">
            $(document).ready(function(){
              swal({
                  title: "Save Success",
                  text: "Data Saved Successfully.",
                  icon: "success",
                  timer: 3000,
                  button: true
              }).then(function() {    
              });                   
            });
          </script>';
  }
  if($this->session->flashdata('tidak')){
    echo    '<script type="text/javascript">
                $(document).ready(function(){
                    swal({
                      title: "Failed",
                      text: "Data Failed to Save.",
                      icon: "error",
                      timer: 3000,
                      button: true
                    }).then(function() {
                    });
                });
            </script>';
    }

    if($this->session->flashdata('ubah')){
        echo    '<script type="text/javascript">
                    $(document).ready(function(){
                      swal({
                        title: "Update Success",
                        text: "Data Successfully Updated.",
                        icon: "info",
                        timer: 3000,
                        button: true
                      }).then(function() {
                      });
                    });
                </script>';
      }
    if($this->session->flashdata('tidak_ubah')){
      echo    '<script type="text/javascript">
                  $(document).ready(function(){
                    swal({
                        title: "Update Failed",
                        text: "Data Failed to Update.",
                        icon: "error",
                        timer: 3000,
                        button: true
                    }).then(function() {
                    });
                  });
                </script>';
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title><?php echo $company_name?></title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <link href="<?php echo base_url();?>Website/assets/img/logo_title.png" rel="icon">
  <link href="<?php echo base_url();?>Website/assets/img/logo_title.png" rel="logo_title">
  <link href="<?php echo base_url();?>Website/assets/css/maps.css" rel="stylesheet">
  <link href="<?php echo base_url();?>Website/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>Website/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?php echo base_url();?>Website/assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?php echo base_url();?>Website/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>Website/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>Website/assets/css/main.css" rel="stylesheet">  
  <script src="<?php echo base_url();?>Website/assets/js/sweetalert.min.js"></script>
  <link rel="stylesheet" href="https://coatingshow.com/css/font-icons.css" type="text/css">
  <link rel="stylesheet" href="https://coatingshow.com/css/animate.css" type="text/css">
  <link rel="stylesheet" href="https://coatingshow.com/css/magnific-popup.css" type="text/css">
</head>

<style>
    .media-carousel 
    {
      margin-bottom: 0;
      padding: 0 40px 30px 40px;
      margin-top: 30px;
    }
    /* Previous button  */
    .media-carousel .carousel-control.left 
    {
      left: -12px;
      background-image: none;
      background: none repeat scroll 0 0 #222222;
      border: 4px solid #FFFFFF;
      border-radius: 23px 23px 23px 23px;
      height: 40px;
      width : 40px;
      margin-top: 30px
    }
    /* Next button  */
    .media-carousel .carousel-control.right 
    {
      right: -12px !important;
      background-image: none;
      background: none repeat scroll 0 0 #222222;
      border: 4px solid #FFFFFF;
      border-radius: 23px 23px 23px 23px;
      height: 40px;
      width : 40px;
      margin-top: 30px
    }
    /* Changes the position of the indicators */
    .media-carousel .carousel-indicators 
    {
      right: 50%;
      top: auto;
      bottom: 0px;
      margin-right: -19px;
    }
    /* Changes the colour of the indicators */
    .media-carousel .carousel-indicators li 
    {
      background: #c0c0c0;
    }
    .media-carousel .carousel-indicators .active 
    {
      background: #333333;
    }
    .media-carousel img
    {
      width: 250px;
      height: 100px
    }

    body {
      color: var(--default-color);
      background-color: var(--background-color);
      font-family: var(--default-font);
      font-family: Poppins, sans-serif;
    }
    .header {
      color: #ffffff;
      background-color: rgba(0, 0, 0, .95);
      padding: 15px 0;
      transition: all 0.5s;
      z-index: 997;
    }

    .header .logo img {
      max-height: 45px;
      margin-right: 8px;
    }

    @media (min-width: 1200px) {
      .navmenu li:hover>a, .navmenu .active, .navmenu .active:focus {
          /* color:#1c9356; */
          color:#fff;
      }
    }

    @media (min-width: 1200px) {
      .navmenu a, .navmenu a:focus {
        color: #ffffff;
        padding: 15px 20px;
        font-size: 15px;
        font-family: var(--nav-font);
        font-weight: 500;
        text-transform: uppercase;
        display: flex;
        align-items: center;
        justify-content: space-between;
        white-space: nowrap;
        transition: 0.3s;
      }
    }

    .hero .carousel {
      width: 100%;
      min-height: 100vh;
      padding: 0;
      margin: 0;
      background-color: var(--background-color);
      position: relative;
    }

    .dark-background {
    --background-color: transparent;
        
    }

    @media (max-width: 1199px) {
      .hero .carousel {
        width: 100%;
        min-height: 30vh;
        padding: 0;
        margin: 0;
        background-color: var(--background-color);
        position: relative;
      }
    }

    .footer {
      color: var(--default-color);
      background-color: black;
      font-size: 14px;
      position: relative;
    }
    
    .section-title h2 { 
      font-size: 46px;
      font-weight: 600;
      text-transform: capitalize;
      margin-bottom: 20px;
      padding-bottom: 0;
      position: relative;
      z-index: 2;
      color: #1c9356;
    }

    .heading_style4.center h2::after {
      margin-left: -65px;
      left: 50%;
    }

    .heading_style4 h2::after {
      background: #111;
      height: 2px;
      left: 0;
      position: absolute;
      bottom: -30px;
      width: 130px;
      margin-left: 0;
    }

    .heading_style1:before, .heading_style3 h2::after, .heading_style4 h2::after, .section-header.heading_style2::after {
      content: "";
    }

    :after, :before {
      -webkit-box-sizing: border-box;
      -moz-box-sizing: border-box;
      box-sizing: border-box;
    }

    .heading_style4 h2 span, .heading_style5 span, .sub_total span, #navigation .nav.navbar-nav a:hover, .top-search .search-btn:hover, #navigation .nav.navbar-nav li .sub-menu li a:hover, .intro_restaurant .intro_text span, .color_icon .fa, .icon_div, .testimonial_footer:after, .post_meta ul li a:hover, .widgets_icon, .footer_top ul li a:hover, .footer_top ul li a:hover:after, .rec_info .rec_meta a:hover, #footer .rec_info a h6:hover, .follow_us ul li a:hover, .footer_style_6 nav ul li a:hover, .footer_style_6 .footer-style-bottom ul li a:hover, .social_group_style3 li a:hover, .experience_list h6, .filter_project_menu li a:hover, .filter_project_menu li.active a, .top-icon i, .portfolio-tab ul li a:hover, .portfolio-tab ul li.active a, .video-play a:hover, .author-text i, ul.page-numbers .page-numbers.next:hover, ul.page-numbers .page-numbers.next:focus, ul.page-numbers .page-numbers.prev:hover, ul.page-numbers .page-numbers.prev:focus, .post_elements ul li a:hover, .post_tags a, .comming-soon-right-header, .intro_restaurant .intro_text span, .heading_style5 span, .menu_list li .menu_price, .restro_menu .btn.outline, .event-schudule h6 a, .header_style3 #navigation .nav.navbar-nav li > a:hover, h1 a:hover, h2 a:hover, h3 a:hover, h4 a:hover, h5 a:hover, h6 a:hover, a:hover h1, a:hover h2, a:hover h3, a:hover h4, a:hover h5, a:hover h6 {
      color: #1c9356;
      fill: #1c9356;
      font-size: 46px;
      font-weight: 600;
      text-transform: capitalize;
      margin-bottom: 20px;
      padding-bottom: 0;
      position: relative;
      z-index: 2;
    }

    @media (max-width: 600px) {
      .section-title h2 , .heading_style4 h2 span {
        font-size: 30px;
        font-weight: 600;
      }
    }

    .portfolio .portfolio-content .portfolio-info .preview-link, .portfolio .portfolio-content .portfolio-info .details-link {
      position: absolute;
      left: calc(50% - 40px);
      font-size: 40px;
      top: calc(50% - 14px);
      color: #fff;
      transition: 0.3s;
      line-height: 1.2;
      margin-left: 1.2rem;
    }
    
    .bi::before, [class^="bi-"]::before, [class*=" bi-"]::before {
      display: inline-block;
      font-family: bootstrap-icons !important;
      font-style: normal;
      font-weight: normal !important;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      text-align: center;
      vertical-align: -.125em;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }

    .features .video-box img {
      position: absolute;
      inset: 0;
      display: block;
      width: 100%;
      height: auto;
      object-fit: cover;
      z-index: 1;
    }

    .features .icon-box .description {
      line-height: 24px;
      font-size: 16px;
      margin-bottom: 0;
      text-align: left;
    }

    .heading_style4.left h2::after {
      margin-left: 0px;
      left: 0%;
    }

    .img-fluid {        
      width: 100%;
    }

    .features{
      padding: 60px 10px 0px;
      margin-bottom: -60px;
    }

    /* .g-4, .gy-4 {
      --bs-gutter-y: 1.5rem;
      padding: 0px 20px 0px;
    } */

    html:not(.no-js) [data-aos^=zoom][data-aos^=zoom].aos-animate {
      opacity: 1;
      -webkit-transform: translateZ(0) scale(1);
      transform: translateZ(0) scale(1);
      /* min-height: 240px; */     
    }

    .portfolio .portfolio-content .portfolio-info h4 {
      font-size: 16px;
      padding: 5px 10px;
      font-weight: 400;
      color: #ffffff;
      display: inline-block;
      background-color: var(--accent-color);
    }

    .black{
      background: #111;
      margin-top: 3rem;
    }

    .faq .faq-container .faq-item h3 {
      font-weight: 600;
      font-size: 26px;
      line-height: 24px;
      margin: 0 30px 0 32px;
      transition: 0.3s;
      cursor: pointer;
      color: black;
    }

    .faq .faq-container .faq-active .faq-content {
      grid-template-rows: 1fr;
      visibility: visible;
      opacity: 1;
      padding-top: 10px;
      color: black;
    }

    .faq .faq-container .faq-active {
      background-color: color-mix(in srgb, var(--default-color), transparent 96%);
      transition: 0.3s;
    }

    .faq .faq-container .faq-active h3, .faq .faq-container .faq-active h3:hover, .faq .faq-container .faq-active .faq-toggle, .faq .faq-container .faq-active .faq-icon, .faq .faq-container .faq-active .faq-content {
      color: #000;
    }

    .faq .faq-container .faq-item {
      background-color: 
      color-mix(in srgb, var(--default-color), transparent 96%);
      position: relative;
      padding: 10px;
      margin-bottom: 20px;
      overflow: hidden;
      transition: 0.3s;
    } 

    .table>thead {
      vertical-align: bottom;
      text-align: center;
      background: gainsboro;
    }

    tbody, td, tfoot, th, thead, tr {
      border-color: #cacaca;
      border-style: solid;
      border-width: 0;
    }
    
    .scroll-top {
      position: fixed;
      visibility: hidden;
      opacity: 0;
      right: 15px;
      bottom: 15px;
      z-index: 99999;
      background-color: #1c9356;
      width: 40px;
      height: 40px;
      border-radius: 4px;
      transition: all 0.4s;
    }

    .stats .stats-item span {
      font-size: 48px;
      display: block;
      color: #1c9356;
      font-weight: 700;
    }

    .contact3 ul {
      margin-bottom: 25px;
    }

    .list-style-none {
      margin: 0;
      padding: 10px;
      list-style: none;
      text-align: left;
      margin-left: 10px;
    }
    .map {
      position: relative;
      margin-top: 10px;
      margin-left: 20px;
      width: max-content;
    }

    input[type=text], input[type=password], input[type=number], input[type=email], input[type=url], input[type=search], select, textarea {
      background: #fff;
      border: 2px solid #d9d9d9;
      border-radius: 0;
      box-shadow: none;
      color: #888;
      font-size: 16px;
      height: 60px;
      line-height: 30px;
      padding: 0 15px;
      width: 100%;
    }

    textarea.form-control {
      padding: 15px;
      height: 160px;
      border: 2px solid #d9d9d9;
    }
    
    .contact .php-email-form button[type=submit] {
      color: var(--contrast-color);
      background: var(--accent-color);
      border: 0;
      padding: 10px 30px;
      transition: 0.4s;
      border-radius: 4px;
      font-weight: 400;
      margin: auto;
      padding: 15px 50px;
      color: #fff;
      line-height: 30px;
      width: -webkit-fill-available;
    }

    iframe {
      border: 0;
      height: 180px;
    }

    .secondary-bg {
      background-color: #111 !important;
      color: #fff;
      position: relative;
    }

    .footer .footer-links {
      margin-bottom: 50px;
      text-align: left;
    }

    .footer .footer-top {
      border-top: 1px solid 
      color-mix(in srgb, var(--default-color), transparent 90%);
    }

    .footer_top {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
    }

    .footer_widgets {
      flex: 0 0 auto;
      margin: 80px auto;
    }

    .footer-about{
      text-align: center;
    }

    @media (max-width: 600px) {
      .footer .footer-links {
        margin-bottom: 0px;
        text-align: left;
        /* margin-left: 10px; */
      }

      .footer .footer-about {
        margin-bottom: 0px;
        text-align: left;
        /* margin-left: 10px; */
      }

      .footer .social-links{
        position: relative;
        left:0%;
      }

      iframe {
        padding: 0px 0px 0px;
        position: initial;
        width: -webkit-fill-available;
      }

      .con_partner{
        width: max-content;
        position: relative;
      }

      .portfolio .portfolio-content {
        position: relative;
        overflow: hidden;
        text-align: center;
      }
    }

    .social-links{
      position: relative;
      left:21%;
    }

    .footer .copyright p {
      margin: 0px 10px;
    }
    
    .img-partner{    
      max-height: 175px;
    }

    .img-event{    
      max-height: 278px;
      max-width: 380px;
    }

    .max-lines {
      display: block;/* or inline-block */
      text-overflow: ellipsis;
      word-wrap: break-word;
      overflow: hidden;
      max-height: 3.6em;
      /* line-height: 1.8em; */
    }

    .max-lines2 {
      display: block;/* or inline-block */
      text-overflow: ellipsis;
      word-wrap: break-word;
      overflow: hidden;
      max-height: 4em;
      /* line-height: 1.8em; */
    }

    .max-lines3 {
      display: block;/* or inline-block */
      text-overflow: ellipsis;
      word-wrap: break-word;
      overflow: hidden;
      max-height: 6.5em;
      /* line-height: 1.8em; */
    }

    .team .member img {
      margin: 0px 0px 20px 0px;
      min-height: 300px;
    }

    .member-content p{
      /* text-align:left; */
      font-family: Poppins, sans-serif;
      margin-top: -12px;
    }

    .img-product{
      height: 185px;
    }

    .section-title span {
      position: relative;
      top: 5px;
      color: black;
      font-weight: 400;
      text-transform: capitalize;
    }

    .section-title .description-title {
      position: absolute;
      top: 4px;
      color: 
      color-mix(in srgb, var(--heading-color), transparent 95%);
      left: 0;
      right: 0;
      z-index: 1;
      font-weight: 700;
      font-size: 52px;
      text-transform: uppercase;
      line-height: 1;
    }

    /* strong {
      color: black;
      font-weight: 400;
      text-transform: capitalize;
    } */

    section, .section {
      color: var(--default-color);
      background-color: var(--background-color);
      padding: 30px 0;
      scroll-margin-top: 85px;
      overflow: clip;
    }
</style>

<style>
  .sponsors-section .slide-logo img {
    max-width: 100%;
    height: auto;
  }

  .slide-logo a {
      height: auto;
  }

  .fl-module img {
      max-width: 100%;
      height: auto;
  }


  .rowsel {
      border: 1px solid rgba(0, 0, 0, .1);
      background: #fff;
      padding: 0.938rem;
      height: 200px;
      width: fit-content;
      aspect-ratio: 3/2;
      ;
  }
  .owl-carousel .owl-item img {
      width: 80%;
      border: 1px solid rgba(0, 0, 0, .1);
      background: #fff;
      padding: 0.938rem;
      height: 200px;
      width: fit-content;
      /* aspect-ratio: 3/2; */
      object-fit: initial;
  }

</style>

<style>
  .menu-item:hover>.menu-link,
  .menu-item.current>.menu-link {
      color: #FFBC00 !important;
  }

  .sub-menu-container .menu-item>.menu-link {
      color: black;
  }

  #primary-menu-trigger,
  #page-menu-trigger {
      display: -ms-flex;
      display: flex;
      opacity: 1;
      pointer-events: auto;
      z-index: 5;
      cursor: pointer;
      font-size: 0.875rem;
      width: 20%;
      height: 47px;
      position: relative;
      left: 5%;
      /* top: -1%; */
      line-height: 90px;
      justify-content: center;
      align-items: center;
      -webkit-transition: opacity .3s ease;
      transition: opacity .3s ease;
  }

  .svg-trigger {
      width: 100px;
      height: 100px;
      cursor: pointer;
      -webkit-tap-highlight-color: transparent;
      transition: transform 400ms;
      -moz-user-select: none;
      -webkit-user-select: none;
      -ms-user-select: none;
      user-select: none;
  }

  .top-phone {
      background-color: #FFBC00;
      border-radius: 50px;
      color: #fff;
      font-weight: bold;
      padding: 10px 14px;
      border-radius: 50px;
  }

  .top-phone:hover {
    background-color: #5B9D0A;
    color: #FFF;
  }



  .owl-carousel .animated {
    -webkit-animation-duration: 1000ms;
    animation-duration: 1000ms;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
  }

  .owl-carousel .owl-animated-in {
      z-index: 0;
  }

  .owl-carousel .owl-animated-out {
      z-index: 1;
  }

  .owl-carousel .fadeOut {
      -webkit-animation-name: fadeOut;
      animation-name: fadeOut;
  }

  @-webkit-keyframes fadeOut {
      0% {
          opacity: 1;
      }

      100% {
          opacity: 0;
      }
  }

  @keyframes fadeOut {
      0% {
          opacity: 1;
      }

      100% {
          opacity: 0;
      }
  }

  .owl-height {
      -webkit-transition: height 500ms ease-in-out;
      -o-transition: height 500ms ease-in-out;
      transition: height 500ms ease-in-out
  }

  .owl-carousel {
      display: none;
      -webkit-tap-highlight-color: transparent;
      position: relative;
      z-index: 1;
      width: 100%;
  }

  .owl-carousel .owl-stage {
      position: relative;
      -ms-touch-action: pan-Y;
  }

  .owl-carousel .owl-stage::after {
      content: ".";
      display: block;
      clear: both;
      visibility: hidden;
      line-height: 0;
      height: 0
  }

  .owl-carousel .owl-stage-outer {
      position: relative;
      overflow: hidden;
      -webkit-transform: translate3d(0, 0, 0);
  }

  .owl-carousel.owl-loaded {
      display: block
  }

  .owl-carousel.owl-loading {
      display: block;
      min-height: 100px;
      background: no-repeat center center;
  }

  .owl-carousel .owl-refresh .owl-item {
      display: none
  }

  .owl-carousel .owl-item {
      position: relative;
      min-height: 1px;
      float: left;
      -webkit-tap-highlight-color: transparent;
      -webkit-touch-callout: none;
  }

  .owl-carousel .owl-item img {
      display: block;
      width: 100%;
      -webkit-transform-style: preserve-3d;
  }

  .slider-element .owl-carousel .owl-item img {
      -webkit-transform-style: preserve-3d;
  }

  .owl-carousel .owl-nav.disabled,
  .owl-carousel .owl-dots.disabled {
      display: none;
  }

  .owl-nav .owl-prev,
  .owl-nav .owl-next,
  .owl-dot,
  .owl-dots button {
      cursor: pointer;
      cursor: hand;
      padding: 0;
      border: 0;
      -webkit-user-select: none;
      -khtml-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
  }

  .owl-carousel.owl-loaded {
      display: block;
  }

  .owl-carousel.owl-loading {
      opacity: 0;
      display: block;
  }

  .owl-carousel.owl-hidden {
      opacity: 0;
  }

  .mega-menu-content .owl-carousel.owl-hidden {
      opacity: 1;
  }

  .owl-carousel.owl-refresh .owl-item {
      display: none;
  }

  .owl-carousel.owl-drag .owl-item {
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
  }

  .owl-carousel.owl-grab {
      cursor: move;
      cursor: -webkit-grab;
      cursor: -o-grab;
      cursor: -ms-grab;
      cursor: grab;
  }

  .owl-carousel.owl-rtl {
      direction: rtl;
  }

  .owl-carousel.owl-rtl .owl-item {
      float: right;
  }

  .no-js .owl-carousel {
      display: block;
  }

  .owl-carousel .owl-item .owl-lazy {
      opacity: 0;
      -webkit-transition: opacity 400ms ease;
      -o-transition: opacity 400ms ease;
      transition: opacity 400ms ease
  }

  .owl-carousel .owl-item img {
      transform-style: preserve-3d
  }

  .owl-carousel .owl-video-wrapper {
      position: relative;
      height: 100%;
      background: #111
  }

  .owl-carousel .owl-video-play-icon {
      position: absolute;
      height: 64px;
      width: 64px;
      left: 50%;
      top: 50%;
      margin-left: -32px;
      margin-top: -32px;
      background: url("images/icons/play.png") no-repeat;
      cursor: pointer;
      z-index: 1;
      -webkit-backface-visibility: hidden;
      -webkit-transition: scale 100ms ease;
      -o-transition: scale 100ms ease;
      transition: scale 100ms ease;
  }

  .owl-carousel .owl-video-play-icon:hover {
      -webkit-transition: scale(1.3, 1.3);
      -o-transition: scale(1.3, 1.3);
      transition: scale(1.3, 1.3)
  }

  .owl-carousel .owl-video-playing .owl-video-play-icon,
  .owl-carousel .owl-video-playing .owl-video-tn {
      display: none
  }

  .owl-carousel .owl-video-tn {
      opacity: 0;
      height: 100%;
      background-position: center center;
      background-repeat: no-repeat;
      -webkit-background-size: contain;
      -moz-background-size: contain;
      -o-background-size: contain;
      background-size: contain;
      -webkit-transition: opacity 400ms ease;
      -o-transition: opacity 400ms ease;
      transition: opacity 400ms ease
  }

  .owl-carousel .owl-video-frame {
      position: relative;
      z-index: 1;
      height: 100%;
      width: 100%;
  }


  /* Owl Carousel - Controls
  -----------------------------------------------------------------*/

  .owl-carousel .owl-dots,
  .owl-carousel .owl-nav {
      text-align: center;
      -webkit-tap-highlight-color: transparent;
      line-height: 1;
  }

  /* Owl Carousel - Controls - Arrows
  -----------------------------------------------------------------*/

  .owl-carousel .owl-nav [class*=owl-] {
      position: absolute;
      top: 50%;
      margin-top: -18px;
      left: -36px;
      zoom: 1;
      width: 36px;
      height: 36px;
      line-height: 32px;
      border: 1px solid rgba(0, 0, 0, 0.2);
      color: #666;
      background-color: #FFF;
      font-size: 18px;
      border-radius: 50%;
      opacity: 0;
      -webkit-transition: all .3s ease;
      -o-transition: all .3s ease;
      transition: all .3s ease;
  }

  .owl-carousel.with-carousel-dots .owl-nav [class*=owl-] {
      margin-top: -38px;
  }

  .slider-element .owl-nav [class*=owl-],
  .owl-carousel-full .owl-nav [class*=owl-] {
      margin-top: -30px;
      left: 0 !important;
      height: 60px;
      line-height: 60px;
      border: none;
      color: #EEE;
      background-color: rgba(0, 0, 0, 0.4);
      font-size: 28px;
      border-radius: 0 3px 3px 0;
  }

  .owl-carousel-full .with-carousel-dots .owl-nav [class*=owl-] {
      margin-top: -50px;
  }

  .owl-carousel .owl-nav .owl-next {
      left: auto;
      right: -36px;
  }

  .slider-element .owl-nav .owl-next,
  .owl-carousel-full .owl-nav .owl-next {
      left: auto !important;
      right: 0 !important;
      border-radius: 3px 0 0 3px;
  }

  .owl-carousel:hover .owl-nav [class*=owl-] {
      opacity: 1;
      left: -18px;
  }

  .owl-carousel:hover .owl-nav .owl-next {
      left: auto;
      right: -18px;
  }

  .owl-carousel .owl-nav [class*=owl-]:hover {
      background-color: #1ABC9C !important;
      color: #FFF !important;
      text-decoration: none;
  }

  .owl-carousel .owl-nav .disabled {
      display: none !important;
  }


  /* Owl Carousel - Controls - Dots
  -----------------------------------------------------------------*/

  .owl-carousel .owl-dots .owl-dot {
      display: inline-block;
      zoom: 1;
      width: 8px;
      height: 8px;
      margin: 30px 4px 0 4px;
      opacity: 0.5;
      border-radius: 50%;
      background-color: #1ABC9C;
      -webkit-transition: all .3s ease;
      -o-transition: all .3s ease;
      transition: all .3s ease;
  }

  .owl-carousel .owl-dots .owl-dot.active,
  .owl-carousel .owl-dots .owl-dot:hover {
      opacity: 1;
  }

  .hero .carousel-item {    
    margin-top: -30px;
  }
 </style>

<body class="index-page">
  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">
      <a href="<?php echo base_url("dashboard");?>" class="logo d-flex align-items-center">
        <img width="215" height="50" src="<?php echo base_url($folder."".$logo);?>" alt="<?php echo base_url($nick_name);?>">
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li class="dropdown"><a href="#"><span>Home</span></a>
            <!-- <ul>
              <li><a href="#about">Company Profile</a></li>
              <li><a href="#partners">Partners</a></li>
            </ul> -->
          </li>
          <li><a href="#product">Products and Services</a></li>
          <li><a href="#event">Events</a></li> 
          <li><a href="#news">News Update</a></li> 
          <li><a href="#contact">Contact Us</a></li> 
          <!--<li><a href="#about">Company Profile</a></li>
          <li><a href="#services">Products and Services</a></li>
          <li><a href="#customer">Customer</a></li>
          <li><a href="#contact">Contact Us</a></li>          -->
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
    </div>
  </header>

  <main class="main">
    <section id="hero" class="hero section dark-background">
      <div id="hero-carousel" class="carousel slide carousel-fade active" data-bs-ride="carousel" data-bs-interval="5000">     
        <?php foreach($data_slide as $row){ 
          $file = $row->folder_name."".$row->file_name;
          $img = "".$file."";

          if($row->urut == 1){
            $act = "active";
          }else{            
            $act = "";
          }
        ?> 
        <div class="carousel-item <?php echo $act; ?>">
          <img src="<?php echo base_url($img); ?>">
        </div>
        <?php } ?>        
        <a class="carousel-control-prev" href="#hero-carousel" role="button" data-bs-slide="prev">
          <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
        </a>
        <a class="carousel-control-next" href="#hero-carousel" role="button" data-bs-slide="next">
          <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
        </a>
        <ol class="carousel-indicators"></ol>
      </div>
    </section>

    <!-- <section id="partners" class="portfolio section">
      <div class="container section-title heading_style4 center" data-aos="fade-up">
        <span class="description-title">Our Partners</span>
        <h2>Our <span>Partners</span></h2>
      </div>

      <div class="container">
        <div class="isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">
          <div class="row gy-4 isotope-container" data-aos-delay="200">
            <?php 
              foreach($data_slide2 as $row2){ 
                $file2 = $row2->folder_name."".$row2->file_name;
                $img2 = "".$file2."";
            ?> 
            <div class="col-lg-3 col-md-1 portfolio-item isotope-item filter-app">
              <div class="portfolio-content h-100">
                <a href="<?php echo $row2->url ?>" class="stretched-link" target="_blank"></a>
                <img src="<?php echo base_url($img2); ?>" class="img-fluid con_partner img-partner" alt="">
              </div>
            </div>
            <?php } ?>
          </div>
        </div>
      </div>
    </section><br><br><br> -->

    <!-- <section id="about" class="features section">
      <?php 
        $n = 1;
        foreach($data_slide3 as $row3){ 
        $file3 = $row3->folder_name."".$row3->file_name;
        $img3 = "".$file3."";

        $explode = explode(" ",$row3->nama);
        $exp = $explode;

        if($n > 1){
          $style = 'style = "margin-top:-60px;"';
        }else{
          $style = "";
        }
      ?> 
      <div class="container section-title heading_style4 left" <?php echo $style ?>>        
        <div class="row gy-4">
          <div class="col-xl-5 col-lg-6" data-aos="zoom-out" data-aos-delay="100">
            <img src="<?php echo base_url($img3);?>" class="img-fluid" alt="">
          </div>
          <div class="col-xl-7 col-lg-6 d-flex flex-column justify-content-center px-lg-5 container section-title heading_style4 center" data-aos-delay="200">
            <div style="text-align:left;margin-left:15px" >
              <h2><?php echo $exp[0];?><span>&nbsp; <?php echo $exp[1];?></span></h2>              
            </div>
            <div class="icon-box d-flex position-relative" style="margin:15px;margin-top: 35px; text-align: left;">
              <div>
                <p class="description">
                  <?php echo $row3->description; ?>
                </p>
              </div>
            </div><br>
          </div>          
        </div>
      </div>        
      <?php
        $n++; 
        } 
      ?>    
    </section><br><br><br> -->

    <section id="about" class="portfolio section">
      <?php 
        $n = 1;
        foreach($data_slide3 as $row3){ 
        $file3 = $row3->folder_name."".$row3->file_name;
        $img3 = "".$file3."";

        $explode = explode(" ",$row3->nama);
        $exp = $explode;

        if($n > 1){
          $style = 'style = "margin-top:-60px;"';
        }else{
          $style = "";
        }
      ?> 
      <div class="col-xl-12 d-flex flex-column justify-content-center container section-title center" data-aos="fade-up">
        <h2><?php echo $exp[0]." ".$exp[1];?></h2>
        <div class="mt-5" style="text-align: left;margin-left:15px">
          <?php echo $row3->description; ?>
        </div>        
      </div>
        
      <div class="container">
        <div class="isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">
          <div class="row gy-4 isotope-container">
            <?php 
              foreach($data_slide2 as $row2){ 
                $file2 = $row2->folder_name."".$row2->file_name;
                $img2 = "".$file2."";
            ?> 
            <div class="col-lg-3 col-md-1 portfolio-item isotope-item filter-app">
              <div class="portfolio-content h-100">
                <a href="<?php echo $row2->url ?>" class="stretched-link" target="_blank"></a>
                <img src="<?php echo base_url($img2); ?>" class="img-fluid con_partner img-partner" alt="">
                <p class="text-center mt-3"><?php echo $row2->nama?></p>
              </div>
            </div>
            <?php } ?>
          </div>
        </div>                
      </div>
      <?php
        $n++; 
        } 
      ?>  
    </section>

    <section id="product" class="portfolio section">
      <div class="container section-title center" data-aos="fade-up">
        <div style=" font-size: 46px;
                    font-weight: 500;
                    margin-bottom: 20px;
                    padding-bottom: 0;
                    position: relative;
                    z-index: 2;
                    color: #1c9356;">Our Products and Services</div>
        <!-- <h2>Our Products and Services</h2> -->
      </div>
      <div class="container">
        <div class="isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">
          <?php 
            foreach($data_slide4 as $row4){ 
              $file4 = $row4->folder_name."".$row4->file_name;
              $img4 = "".$file4."";
              $explode4 = explode(".",$row4->file_name);
              $exp4 = $explode4;
          ?> 
          <div class="row gy-4 isotope-container" data-aos-delay="200">
            <div class="col-lg-2 col-md-3 portfolio-item isotope-item filter-app">
              <div class="portfolio-content h-100">
                <?php if($exp4[1] == "pdf"){?>                  
                  <iframe class="responsive" src="<?php echo $file4."#toolbar=0&navpanes=0&scrollbar=0'frameBorder='0'scrolling='none'";?>"  frameborder="0" allowfullscreen="" webkitallowfullscreen=""></iframe>
                  <!-- <embed src="<?php echo $file4?>" type="application/pdf" class="img-fluid responsive"> -->
                  <!-- <object width="400" type="application/pdf" data="<?php echo $file4?>?#zoom=85&scrollbar=0&toolbar=0&navpanes=0"></object> -->
                <?php }else{ ?>                
                  <img src="<?php echo base_url($img4); ?>" class="img-fluid img-product" alt="">
                <?php } ?>
                <div class="portfolio-info">
                  <h4><?php echo $row4->nama?></h4>
                  <!-- <p>Chem Cleaner Brochure</p> -->
                  <a href="<?php echo base_url($img4); ?>" data-gallery="portfolio-gallery-app" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                  <!-- <a href="portfolio-details.html" title="More Details" class="details-link"><i class="bi bi-link-45deg"></i></a> -->
                </div>
              </div>
            </div>
            <?php } ?>
          </div>
        </div>
      </div>
    </section>

    <section id="event" class="team section">
      <div class="container section-title aos-init aos-animate" data-aos="fade-up">
        <!-- <div class="description-title">Event</div> -->
        <h2>Event</h2>
      </div>
      <div class="container">             
        <div class="row">
          <?php 
            foreach($data_event as $row5){
              $id5 = $row5->id; 
              $file5 = $row5->folder_name."".$row5->file_name;
              $img5 = "".$file5."";
          ?> 
          <div class="col-lg-4 col-md-6 d-flex aos-init aos-animate" data-aos-delay="100">
            <div class="member">
              <img src="<?php echo base_url($img5); ?>" class="img-fluid img-event " alt="">
              <div class="member-content max-lines3">
                <h4><a href="<?php echo base_url("event/event_update/".$id5);?>" class=""><?php echo $row5->nama?></a></h4>
                <p class="konten_text">
                  <!-- Magni qui quod omnis unde et eos fuga et exercitationem. Odio veritatis perspiciatis quaerat qui aut aut aut -->
                  <?php echo $row5->description?>
                </p>
              </div>
            </div>
          </div>
          <?php } ?>
        </div>        
      </div>
    </section>

    <section id="news" class="services section">
      <div class="container section-title center" data-aos="fade-up">
        <!-- <div class="description-title">News Update</span> -->
        <h2>News Update</h2>
      </div>
      <div class="container">
        <div class="row gy-4">
          <?php 
            foreach($data_news as $row6){ 
              $id6 = $row6->id;
              $file6 = $row6->folder_name."".$row6->file_name;
              $img6 = "".$file6."";
          ?> 
          <div class="col-md-6 aos-init">
            <div class="service-item d-flex position-relative h-100">
              <i class="bi bi-globe icon flex-shrink-0"></i>
              <div class="max-lines2">
                <h4 class="title"><a href="<?php echo base_url("news/info_news/".$id6);?>" title="Info News"><?php echo ucwords($row6->nama)?></a></h4>
                <p class="description max-lines"><?php echo $row6->description?></p>
              </div>
            </div>
          </div>    
          <?php } ?>     
        </div>
      </div>
    </section> 

    <section id="customer" class="faq section">
      <div class="container section-title center" data-aos="fade-up">
        <!-- <div class="description-title">Our Customer</div> -->
        <h2>Our Customer</h2>
      </div>

      <div class="container">
        <div class="row justify-content-left">
          <div class="col-lg-12">
            <!-- <div class="faq-container">
              <div class="faq-item" data-aos-delay="200">
                <h3>Domestic Customer</h3>
                <div class="faq-content">
                  <div style="min-height:10px"><hr>
                    <table class="table table-bordered">
                      <thead class="table-active">
                        <tr>
                          <th width="5%">NO</th>
                          <th>CUSTOMER</th>
                          <th>GOODS / SERVICE</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php 
                          $nt = 1;
                          foreach($tbl_dom as $r_tbl){
                            echo "<tr>
                                    <td align=\"center\">".$nt."</td>
                                    <td>".$r_tbl->nama."</td>
                                    <td>".$r_tbl->services."</td>
                                  </tr>";
                            $nt++;
                          }
                        ?>
											</tbody>
                    </table>
                  </div>                 
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div>

              <div class="faq-item" data-aos-delay="300">
                <h3>Overseas Customer</h3>
                <div class="faq-content">
                  <div style="min-height:10px"><hr>
                    <table class="table table-bordered">
                      <thead class="table-active">
                        <tr>
                          <th>NO</th>
                          <th>CUSTOMER</th>
                          <th>GOODS / SERVICE</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php 
                          $nt2 = 1;
                          foreach($tbl_over as $r_tbl2){
                            echo "<tr>
                                    <td align=\"center\">".$nt2."</td>
                                    <td>".$r_tbl2->nama."</td>
                                    <td>".$r_tbl2->services."</td>
                                  </tr>";
                            $nt2++;
                          }
                        ?>
										  </tbody>
                    </table>
                  </div>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div>
            </div> -->

            <!-- <div class="container">
              <div class="isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">
                <div class="row gy-4 isotope-container">
                  <?php 
                    foreach($data_slide5 as $row5){ 
                      $file5 = $row5->folder_name."".$row5->file_name;
                      $img5 = "".$file5."";
                  ?> 
                  <div class="col-lg-3 col-md-1 portfolio-item isotope-item filter-app">
                    <div class="portfolio-content h-100">
                      <a href="<?php echo $row5->url ?>" class="stretched-link" target="_blank"></a>
                      <img src="<?php echo base_url($img5); ?>" class="img-fluid con_partner img-partner" alt="">
                      <p class="text-center mt-3"><?php echo $row5->nama?></p>
                    </div>
                  </div>

                 
                  <?php } ?>
                </div>
              </div>                
            </div> -->

            <div class="container">
              <div id="media-partner-carousel" class="owl-carousel owl-carousel1 image-carousel carousel-widget owl-loaded owl-drag" data-margin="30" data-loop="true" data-nav="true" data-pagi="false" data-items-xs="1" data-autoplay="5000" data-items-sm="8" data-items-md="6" data-items-lg="6" data-items-xl="4">
                <div class="owl-stage-outer">
                  <div class="owl-stage">
                    <?php 
                      // foreach($data_slide4 as $row4){ 
                      //   $file4 = $row4->folder_name."".$row4->file_name;
                      //   $img4 = "".$file4."";
                      //   $explode4 = explode(".",$row4->file_name);
                      //   $exp4 = $explode4;

                      foreach($data_slide5 as $row5){ 
                        $file5 = $row5->folder_name."".$row5->file_name;
                        $img5 = "".$file5."";
                    ?> 
                      
                    <div class="owl-item cloned">
                      <div class="oc-item" style="text-align:center">
                        <a href="<?php echo $row5->url ?>" target="_blank" rel="noopener noreferrer">
                          <img src="<?php echo base_url($img5); ?>" class="day rowsel" width="10%" title="Supported" alt="Supported">
                        </a>
                        <!-- <h7><?php echo $row4->nam5?></h7> -->
                      </div>
                    </div>                          
                    <?php } ?>
                  </div>
                </div>
                <div class="owl-nav">
                  <button type="button" role="presentation" class="owl-prev">
                    <i class="icon-angle-left"></i>
                  </button>
                <button type="button" role="presentation" class="owl-next">
                  <i class="icon-angle-right"></i>
                </button></div>
                <div class="owl-dots disabled"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>    

    <section id="contact" class="contact section">
      <div class="container section-title center" data-aos="fade-up">
        <!-- <div class="description-title">Contact Us</span> -->
        <h2>Contact Us</h2>
      </div>
      
      <div class="container">        
        <div class="row gy-4">
          <div class="col-xl-6 col-lg-6">
            <form action="<?php echo base_url(); ?>Dashboard/submit_form" method="post" class="php-email-form" data-aos-delay="200" style="margin: 20px;">
              <div class="row gy-4">
                <div class="col-md-6">
                  <input type="text" name="name" class="form-control" placeholder="Your Name" style="text-transform:capitalize" required="">
                </div>
                <div class="col-md-6 ">
                  <input type="email" class="form-control" name="email" placeholder="Your Email" required="">
                </div>
                <div class="col-md-12">
                  <input type="number" class="form-control" name="hp" placeholder="Mobile Phone" required="">
                </div>
                <div class="col-md-12">
                  <input type="text" class="form-control" name="company" placeholder="Company" style="text-transform:capitalize" required="">
                </div>
                <div class="col-md-12">
                  <input type="text" class="form-control" name="position" placeholder="Position" required="">
                </div>
                <div class="col-md-12">
                  <input type="text" class="form-control" name="subject" placeholder="Subject" required="">
                </div>
                <div class="col-md-12">
                  <textarea class="form-control" name="message" rows="6" placeholder="Message" required=""></textarea>
                </div>
                <div class="col-md-12 text-center">
                  <button type="submit">Send Message</button>
                </div>
              </div>
            </form>
          </div>
          <div class="col-xl-6 col-lg-6">
            <ul class="list-style-none">
              <li>Email : <a href="mailto:contact@keliechem.com"><?php echo $email?></a></li>
              <li>Phone: <a href="tel:+62214532003"><?php echo $phone?></a></li><br>
              <li>Give us a call or drop by anytime, we endeavour to answer all enquiries within 24 hours on business days.</li><br>
              <li>We are open from 9AM – 5PM week days.</li>
            </ul>
            <div class="map">
			        <iframe src="<?php echo trim($gmaps)?>" width="500" style="height:300px" frameborder="0" style="border:0" allowfullscreen=""></iframe>		  
            </div>
          </div>          
        </div>
      </div>
    </section>
  </main>

  <footer id="footer" class="footer dark-background">
    <div class="container footer-top">
      <div class="row gy-4">
        <div class="col-lg-4 footer-about">
          <img width="215" height="50" src="<?php echo base_url($folder."".$logo);?>" class="attachment-full size-full" alt="">
          <div class="social-links d-flex mt-3">
            <?php 
              foreach($data_sosmed as $row_sosmed){ 
            ?> 
            <a href="<?php echo $row_sosmed->url ?>" title="<?php echo ucwords($row_sosmed->nama)?>"><i class="<?php echo "bi bi-".$row_sosmed->icon;?>"></i></a>
            <?php } ?>
          </div>
        </div>
        
        <div class="col-lg-1 col-md-3 footer-links">
        </div>
        <div class="col-lg-3 col-md-3 footer-links">
          <p>
            <strong  class="text-left">
              <?php echo $company_name?>
            </strong><br>
            <?php echo $address?>
          </p>
        </div>

        <div class="col-lg-1 col-md-3 footer-links">
        </div>

        <div class="col-lg-3 footer-links">
          <!-- <p>Phone: <a href="tel:"<?php echo $phone?>><?php echo $phone?></a><br>
            Fax: <a href="tel:"<?php echo $fax?>><?php echo $fax?></a><br>
            email : <a href="mailto:"<?php echo $email?>><?php echo $email?></a><br>
            Website: <a href="<?php echo $website?>"><?php echo $website?></a>            
          </p> -->
          <table width="100%">
            <tr>
              <td width="25%">Phone</td>
              <td width="5%" align="center">:</td>
              <td><a href="tel:"<?php echo $phone?>><?php echo $phone?></a></td>
            </tr>
            <tr>
              <td width="25%">Email</td>
              <td width="5%" align="center">:</td>
              <td><a href="mailto:"<?php echo $email?>><?php echo $email?></a></td>
            </tr>
            <tr>
              <td width="25%">Website</td>
              <td width="5%" align="center">:</td>
              <td><a href="<?php echo $website?>"><?php echo $website?></a></td>
            </tr>
          </table>
        </div>
      </div>
    </div>

    <div class="container copyright text-center mt-4">
    <p>Copyright © <?php echo date('Y');?> <?php echo $company_name?>. All Right Reserved.</p>
    </div>
  </footer>

  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <!-- <div id="preloader"></div> -->
</body>

<script src="<?php echo base_url();?>Website/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- <script src="<?php echo base_url();?>Website/assets/vendor/php-email-form/validate.js"></script> -->
<script src="<?php echo base_url();?>Website/assets/vendor/aos/aos.js"></script>
<script src="<?php echo base_url();?>Website/assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="<?php echo base_url();?>Website/assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="<?php echo base_url();?>Website/assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="<?php echo base_url();?>Website/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="<?php echo base_url();?>Website/assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="<?php echo base_url();?>Website/assets/js/main.js"></script>

<script src="<?php echo base_url();?>Website/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>Website/assets/js/jquery.cookie.min.js"></script>
<script type="text/javascript">  
  $(document).ready(function() {      
    $.getJSON('https://ipinfo.io/json', function(data) {
      var ip = JSON.stringify(data["ip"], null, 2);
      var city = JSON.stringify(data["city"], null, 2);
      var country = JSON.stringify(data["country"], null, 2);
      var loc = JSON.stringify(data["loc"], null, 2);
      var org = JSON.stringify(data["org"], null, 2);
      var timezone = JSON.stringify(data["timezone"], null, 2);
      //console.log(JSON.stringify(data, null, 2));
      //console.log(ip+" - "+city+" - "+country+" - "+loc+" - "+org+" - "+timezone);

      $.ajax({
          url: "<?php echo base_url()?>Login/save_ip_visitor",
          type: 'post',
          data: {ip : ip, city : city, country : country, loc : loc, org : org, timezone : timezone},
          success: function (data) {
            //console.log(data);      
          }
      });  
    });
  });  
</script>

<script src="https://coatingshow.com/js/plugins.min.js"></script>
<script src="https://coatingshow.com/js/functions.js"></script>

<script src="https://npmcdn.com/flickity@2/dist/flickity.pkgd.js"></script>
<script src="https://coatingshow.com/js/components/bs-filestyle.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
</html>