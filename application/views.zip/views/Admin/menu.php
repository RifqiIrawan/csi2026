<nav class="sidebar sidebar-offcanvas" id="get_menu">
      <div class="sidebar-brand-wrapper d-none d-lg-flex align-items-center justify-content-center fixed-top">
        <span class="sidebar-brand brand-logo">
          <img class="img-xs rounded-circle " src="<?php echo base_url();?>Website/assets/img/logo-2.png" alt="" id="post_logo">
        </span>
      </div>
      <ul class="nav">
        <li class="nav-item profile">
          <div class="profile-desc">
            <div class="profile-pic">
              <div class="count-indicator">
                <img class="img-xs rounded-circle " src="<?php echo base_url();?>assets/images/faces/user.png" alt="">
                <span class="count bg-success"></span>
              </div>
              <div class="profile-name">
                <h5 class="mb-0 font-weight-normal"><?php echo ucwords($this->session->userdata('nama'))?></h5>
                <span><?php echo ucwords($this->session->userdata('namalevel'))?></span>
              </div>
            </div>
            <div class="dropdown-menu dropdown-menu-right sidebar-dropdown preview-list" aria-labelledby="profile-dropdown">
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-dark rounded-circle">
                    <i class="mdi mdi-human"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject ellipsis mb-1 text-small">Profil User</p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-dark rounded-circle">
                    <i class="mdi mdi-lock-outline"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject ellipsis mb-1 text-small">Ubah Password</p>
                </div>
              </a>
            </div>
          </div>
        </li>
        <li class="nav-item nav-category">
          <span class="nav-link">Navigation</span>
        </li> 

      
        
        <li class="nav-item menu-items">
          <a class="nav-link" data-toggle="collapse" href="#menu1" aria-expanded="false" aria-controls="menu1">
            <span class="menu-icon">
              <i class="mdi mdi-home"></i>
            </span>
            <span class="menu-title">Home</span>
            <i class="menu-arrow"></i>
          </a>
          <div class="collapse" id="menu1">
            <ul class="nav flex-column sub-menu">
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Content1');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Header Content</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Book_Stand');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Book A Stand</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Floor_Plan');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Floor Plan</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Date_Event');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Logo & Date Event</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Carousel');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Carousel</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Profile');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Logo & Event Profile</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Product');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Product Sector</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Event_Value');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Highlights Attendees</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Highlights');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Show Highlights Video</a></li> 
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Coperation');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;In Cooperation</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Sponsors');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Sponsors</a></li> 
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Support');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Supported By</a></li>

              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Link_Event');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Link Event (EMS)</a></li> 

            </ul>
          </div>
        </li>

        <li class="nav-item menu-items">
          <a class="nav-link collapsed" data-toggle="collapse" href="#menu2" aria-expanded="false" aria-controls="menu2">
            <span class="menu-icon">
              <i class="mdi mdi-chevron-double-down"></i>
            </span>
            <span class="menu-title">Footer</span>
            <i class="menu-arrow"></i>
          </a>
          <div class="collapse" id="menu2">
            <ul class="nav flex-column sub-menu">
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Organizer');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Organizer By</a></li> 
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Member');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Member Of</a></li> 
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Quick_Link');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Quick Link</a></li> 
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Contact');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Contact</a></li> 
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Sosmed');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Sosial Media</a></li> 

            </ul>
          </div>
        </li>

        <li class="nav-item menu-items">
          <a class="nav-link collapsed" data-toggle="collapse" href="#menu3" aria-expanded="false" aria-controls="menu3">
            <span class="menu-icon">
              <i class="mdi mdi-chevron-double-down"></i>
            </span>
            <span class="menu-title">Information</span>
            <i class="menu-arrow"></i>
          </a>
          <div class="collapse" id="menu3">
            <ul class="nav flex-column sub-menu">
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Info/Form_Visitor_Information');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Visitor Information</a></li> 
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Info/Hotel');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Booking Hotel</a></li> 

            </ul>
          </div>
        </li>

        <li class="nav-item menu-items">
          <a class="nav-link collapsed" data-toggle="collapse" href="#menu4" aria-expanded="false" aria-controls="menu4">
            <span class="menu-icon">
              <i class="mdi mdi-chevron-double-down"></i>
            </span>
            <span class="menu-title">Contact</span>
            <i class="menu-arrow"></i>
          </a>
          <div class="collapse" id="menu4">
            <ul class="nav flex-column sub-menu">
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Info/Form_Contact');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Header Contact</a></li> 
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Info/Submit_Form');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Submit Form</a></li> 

            </ul>
          </div>
        </li>

        <li class="nav-item menu-items">
          <a class="nav-link collapsed" data-toggle="collapse" href="#menu5" aria-expanded="false" aria-controls="menu5">
            <span class="menu-icon">
              <i class="mdi mdi-chevron-double-down"></i>
            </span>
            <span class="menu-title">News</span>
            <i class="menu-arrow"></i>
          </a>
          <div class="collapse" id="menu5">
            <ul class="nav flex-column sub-menu">
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Info/Header_News');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Header News</a></li> 
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Info/Form_News_Update');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;News Update</a></li> 

            </ul>
          </div>
        </li>

        


       

        <!-- Exhibiting Menu -->
        <li class="nav-item menu-items">
          <a class="nav-link" data-toggle="collapse" href="#exhibitingMenu" aria-expanded="false" aria-controls="exhibitingMenu" data-parent="#exhibitingMenu">
            <span class="menu-icon">
              <i class="mdi mdi-briefcase"></i>
            </span>
            <span class="menu-title">Exhibiting</span>
            <i class="menu-arrow"></i>
          </a>
          <div class="collapse" id="exhibitingMenu" data-parent="#exhibitingMenu">
            <ul class="nav flex-column sub-menu">

              <!-- Why Exhibit with Sub Menu -->
              <li class="nav-item">
                <a class="nav-link" href="<?php echo site_url('exhibiting/why-exhibit-settings'); ?>">
                  <i class="mdi mdi-arrow-right-bold"></i>&nbsp;Why Exhibit
                </a>
              </li>

              <!-- Other Exhibiting Pages -->
              <li class="nav-item">
                <a class="nav-link" href="<?php echo site_url('exhibiting/exhibitor-list-settings'); ?>">
                  <i class="mdi mdi-arrow-right-bold"></i>&nbsp;Exhibitor List
                </a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="<?php echo site_url('exhibiting/exhibitor-visa-settings'); ?>">
                  <i class="mdi mdi-arrow-right-bold"></i>&nbsp;Exhibitor Visa
                </a>
              </li>

            </ul>
          </div>
        </li>

        <!-- Visiting Menu -->
        <li class="nav-item menu-items">
          <a class="nav-link" data-toggle="collapse" href="#visitingMenu" aria-expanded="false" aria-controls="visitingMenu" data-parent="#visitingMenu">
            <span class="menu-icon">
              <i class="mdi mdi-account-group-outline"></i>
            </span>
            <span class="menu-title">Visiting</span>
            <i class="menu-arrow"></i>
          </a>
          <div class="collapse" id="visitingMenu" data-parent="#visitingMenu">
            <ul class="nav flex-column sub-menu">

              <!-- Visiting with Sub Menu -->
              <li class="nav-item">
                <a class="nav-link" href="<?php echo site_url('visiting/why-visit-settings'); ?>">
                  <i class="mdi mdi-arrow-right-bold"></i>&nbsp;Why Visit
                </a>
              </li>

              <!-- <li class="nav-item">
                <a class="nav-link" href="<?php echo site_url('visiting/conference-schedule-settings'); ?>">
                  <i class="mdi mdi-arrow-right-bold"></i>&nbsp;Conference Schedule
                </a>
              </li> -->

              <li class="nav-item">
                <a class="nav-link" href="<?php echo site_url('visiting/post-show-report-settings'); ?>">
                  <i class="mdi mdi-arrow-right-bold"></i>&nbsp;Post Show Report
                </a>
              </li>

            </ul>
          </div>
        </li>

        <li class="nav-item menu-items">
          <a class="nav-link" data-toggle="collapse" href="#setting" aria-expanded="false" aria-controls="setting">
            <span class="menu-icon">
              <i class="mdi mdi-settings"></i>
            </span>
            <span class="menu-title">Settings</span>
            <i class="menu-arrow"></i>
          </a>
          <div class="collapse" id="setting">
            <ul class="nav flex-column sub-menu">
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Menu');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Menu</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Home/Sub_Menu');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Sub Menu</a>
              <li class="nav-item"><a class="nav-link" href="<?php echo site_url('userlogin');?>"><i class="mdi mdi-arrow-right-bold"></i>&nbsp;&nbsp;Account Login</a></li>
            </ul>
          </div>
        </li>

      
      </ul>
    </nav>
    <div class="container-fluid page-body-wrapper">
    <nav class="navbar p-0 fixed-top d-flex flex-row">
      <div class="navbar-menu-wrapper flex-grow d-flex align-items-stretch">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="mdi mdi-menu"></span>
        </button>
        <ul class="navbar-nav w-100">
          <li class="nav-item w-100" style="padding:15px">
            <input type="text" class="form-control" placeholder="Search" id="search_form">            
          </li>
        </ul>
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item dropdown d-none d-lg-block">
            <!-- <a class="nav-link btn btn-success create-new-button" id="createbuttonDropdown" data-toggle="dropdown" aria-expanded="false" href="#">+ Create New Project</a> -->
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="createbuttonDropdown">
              <h6 class="p-3 mb-0">Projects</h6>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon rounded-circle">
                    <i class="mdi mdi-file-outline text-primary"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject ellipsis mb-1">Software Development</p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-dark rounded-circle">
                    <i class="mdi mdi-web text-info"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject ellipsis mb-1">UI Development</p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-dark rounded-circle">
                    <i class="mdi mdi-layers text-danger"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject ellipsis mb-1">Software Testing</p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <p class="p-3 mb-0 text-center">See all projects</p>
            </div>
          </li>
          <!-- <li class="nav-item nav-settings d-none d-lg-block">
            <a class="nav-link" href="#">
              <i class="mdi mdi-view-grid"></i>
            </a>
          </li>
          <li class="nav-item dropdown border-left">
            <a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <i class="mdi mdi-email"></i>
              <span class="count bg-success"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown">
              <h6 class="p-3 mb-0">Messages</h6>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <img src="<?php echo base_url();?>assets/images/faces/face4.jpg" alt="image" class="rounded-circle profile-pic">
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject ellipsis mb-1">Mark send you a message</p>
                  <p class="text-muted mb-0"> 1 Minutes ago </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <img src="<?php echo base_url();?>assets/images/faces/face2.jpg" alt="image" class="rounded-circle profile-pic">
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject ellipsis mb-1">Cregh send you a message</p>
                  <p class="text-muted mb-0"> 15 Minutes ago </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <img src="<?php echo base_url();?>assets/images/faces/face3.jpg" alt="image" class="rounded-circle profile-pic">
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject ellipsis mb-1">Profile picture updated</p>
                  <p class="text-muted mb-0"> 18 Minutes ago </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <p class="p-3 mb-0 text-center">4 new messages</p>
            </div>
          </li>
          <li class="nav-item dropdown border-left">
            <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
              <i class="mdi mdi-bell"></i>
              <span class="count bg-danger"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
              <h6 class="p-3 mb-0">Notifications</h6>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-dark rounded-circle">
                    <i class="mdi mdi-calendar text-success"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject mb-1">Event today</p>
                  <p class="text-muted ellipsis mb-0"> Just a reminder that you have an event today </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-dark rounded-circle">
                    <i class="mdi mdi-settings text-danger"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject mb-1">Settings</p>
                  <p class="text-muted ellipsis mb-0"> Update dashboard </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-dark rounded-circle">
                    <i class="mdi mdi-link-variant text-warning"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject mb-1">Launch Admin</p>
                  <p class="text-muted ellipsis mb-0"> New admin wow! </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <p class="p-3 mb-0 text-center">See all notifications</p>
            </div>
          </li> -->
          <li class="nav-item dropdown">
            <a class="nav-link" id="profileDropdown" href="#" data-toggle="dropdown">
              <div class="navbar-profile">
                <img class="img-xs rounded-circle" src="<?php echo base_url();?>assets/images/faces/user.png" alt="">
                <p class="mb-0 d-none d-sm-block navbar-profile-name"><?php echo ucwords($this->session->userdata('nama'))?></p>
                <i class="mdi mdi-menu-down d-none d-sm-block"></i>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="profileDropdown">
              <!-- <h6 class="p-3 mb-0">Profile</h6>
              <div class="dropdown-divider"></div> -->
              <!-- <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-dark rounded-circle">
                    <i class="mdi mdi-settings text-success"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject mb-1">Settings</p>
                </div>
              </a> -->
              <!-- <div class="dropdown-divider"></div> -->
              <a class="dropdown-item preview-item" href="<?php echo base_url()?>Login/logout">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-dark rounded-circle">
                    <i class="mdi mdi-logout text-danger"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <p class="preview-subject mb-1">Log out</p>
                </div>
              </a>              
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" id="add_menu">
          <span class="mdi mdi-format-line-spacing"></span>
        </button>
      </div>
    </nav>        
    <div class="main-panel">